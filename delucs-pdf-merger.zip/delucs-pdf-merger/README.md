# DeLucs PDF Merger

This repository contains a Windows PowerShell script that provides a simple GUI for merging multiple PDF files into a single document.  Instead of relying on .NET PDF libraries, the script shells out to the Ghostscript command‑line interface (`gswin64c.exe`/`gswin32c.exe`) to perform the merge.  A drag‑and‑drop Windows Forms interface makes it easy to collect files, reorder them, and save the result.

## Features

- **Drag and drop** PDF files and even entire folders onto the list box.
- **Reorder** files with “Move up”/“Move down” buttons.
- **Remove** selected entries from the list before merging.
- **Optional alphabetical sorting** before the merge.
- Uses Ghostscript via the command line, so there is no dependency on PdfSharp or other DLLs.

## Prerequisites

The script is designed for Windows and requires the following:

1. **PowerShell** – Windows PowerShell (ships with Windows 10/11).  If your execution policy prevents scripts from running, see the tip below.
2. **Ghostscript** – Download and install Ghostscript from the [official Ghostscript downloads page](https://www.ghostscript.com/download.html).  The script will attempt to locate `gswin64c.exe`/`gswin32c.exe` automatically.  You can also set a `GHOSTSCRIPT_EXE` environment variable pointing directly to the executable.

## Usage

1. Clone this repository or download just the [`DeLucs-PDF-Merger.ps1`](DeLucs-PDF-Merger.ps1) file.
2. Ensure Ghostscript is installed and accessible.  On 64‑bit Windows, `gswin64c.exe` is typically installed under `C:\Program Files\gs`.
3. Open a PowerShell window and navigate to the folder containing the script.
4. Run the script:

```powershell
./DeLucs-PDF-Merger.ps1
```

5. In the GUI that appears:

   - Drag and drop PDF files or folders onto the list box.
   - Use **Add PDFs…** to browse for files.
   - Use **Move up** and **Move down** to reorder the files.
   - Tick **Sort alphabetically before merge** if you want to override the order with an alphabetical sort.
   - Click **Merge & Save…** to choose an output filename and location.  The merged PDF will be generated using Ghostscript.

### Execution policy tip

On some systems, running unsigned scripts may be blocked by PowerShell’s execution policy.  If you encounter a warning such as *“running scripts is disabled on this system”*, you can either unblock the file or temporarily relax the policy:

```powershell
# Unblock the specific script
Unblock-File -Path ./DeLucs-PDF-Merger.ps1

# OR: temporarily allow script execution for the current process
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

## License

This project is licensed under the MIT License.  See the [LICENSE](LICENSE) file for details.