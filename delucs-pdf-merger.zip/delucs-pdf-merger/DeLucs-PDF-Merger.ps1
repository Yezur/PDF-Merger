﻿# ============================
# Fancy PDF Merger using Ghostscript
# - No PdfSharp, no DLL hassle
# - Uses Ghostscript CLI (gswin64c.exe / gswin32c.exe)
# - Drag & drop, reorder, remove, merge
# ============================

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# -----------------------------------------
# Find Ghostscript executable
# -----------------------------------------
function Get-GhostscriptPath {
    # Figure out the "app folder" – works in .ps1 and in compiled EXE
    $base = $null

    if ($PSCommandPath) {
        # When running as .ps1
        $base = Split-Path -Parent $PSCommandPath
    }
    elseif ($PSScriptRoot) {
        $base = $PSScriptRoot
    }
    else {
        # When running as compiled EXE: use current process module
        $exePath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        $base    = [System.IO.Path]::GetDirectoryName($exePath)
    }

    # Safety: if for some reason base is still empty, fall back to current directory
    if ([string]::IsNullOrWhiteSpace($base)) {
        $base = (Get-Location).Path
    }

    # 0) Look for a local "gs" folder next to the EXE/script
    $localGsRoot = Join-Path $base "gs"
    if (Test-Path $localGsRoot) {
        $localCandidates = Get-ChildItem -Path $localGsRoot -Recurse `
            -Include "gswin64c.exe","gswin32c.exe" -ErrorAction SilentlyContinue
        if ($localCandidates) {
            return ($localCandidates | Sort-Object FullName -Descending | Select-Object -First 1).FullName
        }
    }

    # 1) If user set an env var, prefer that
    if ($env:GHOSTSCRIPT_EXE -and (Test-Path $env:GHOSTSCRIPT_EXE)) {
        return $env:GHOSTSCRIPT_EXE
    }

    # 2) Try PATH (gswin64c/gswin32c/gs)
    foreach ($name in @("gswin64c.exe", "gswin32c.exe", "gs.exe")) {
        $cmd = Get-Command $name -ErrorAction SilentlyContinue
        if ($cmd -and (Test-Path $cmd.Source)) {
            return $cmd.Source
        }
    }

    # 3) Common install directories
    $roots = @("C:\Program Files\gs", "C:\Program Files (x86)\gs")
    $candidates = foreach ($root in $roots) {
        if (-not (Test-Path $root)) { continue }
        Get-ChildItem $root -Recurse -Include "gswin64c.exe","gswin32c.exe" -ErrorAction SilentlyContinue
    }

    if ($candidates -and $candidates.Count -gt 0) {
        return ($candidates | Sort-Object FullName -Descending | Select-Object -First 1).FullName
    }

    return $null
}


# -----------------------------------------
# Merge PDFs with Ghostscript
# -----------------------------------------
function Merge-PDFsGhostscript {
    param(
        [string[]]$Files,
        [string]$Output,
        [System.Windows.Forms.Label]$StatusLabel = $null
    )

    if (-not $Files -or $Files.Count -lt 2) {
        throw "Need at least 2 PDF files to merge."
    }

    $gsPath = Get-GhostscriptPath
    if (-not $gsPath) {
        throw "Ghostscript executable not found. Please install Ghostscript and/or set GHOSTSCRIPT_EXE environment variable."
    }

    # Ensure output directory exists
    $outDir = Split-Path $Output -Parent
    if ($outDir -and -not (Test-Path $outDir)) {
        New-Item -ItemType Directory -Path $outDir -Force | Out-Null
    }

    if ($StatusLabel) {
        $StatusLabel.Text = "Merging PDFs with Ghostscript..."
        [System.Windows.Forms.Application]::DoEvents()
    }

    # Build argument list – each element separate so spaces are handled correctly
    $arguments = @(
        "-dBATCH",
        "-dNOPAUSE",
        "-q",
        "-sDEVICE=pdfwrite",
        "-sOutputFile=$Output"
    ) + $Files

    # Run Ghostscript via PowerShell's native & so it handles quoting for us
    $output = & $gsPath @arguments 2>&1
    $exitCode = $LASTEXITCODE

    if ($exitCode -ne 0) {
        throw "Ghostscript failed (exit code $exitCode). Output:`n$output"
    }

    if ($StatusLabel) {
        $StatusLabel.Text = "Done. Saved to:`n$Output"
        [System.Windows.Forms.Application]::DoEvents()
    }
}


# -----------------------------------------
# Helper: Add files to ListBox (with checks)
# -----------------------------------------
function Add-FilesToListBox {
    param(
        [System.Windows.Forms.ListBox]$ListBox,
        [string[]]$Paths
    )

    foreach ($path in $Paths) {
        if (-not (Test-Path $path)) { continue }

        if ((Get-Item $path).PSIsContainer) {
            $pdfs = Get-ChildItem $path -Recurse -Include *.pdf -ErrorAction SilentlyContinue
            foreach ($pdf in $pdfs) {
                if (-not $ListBox.Items.Contains($pdf.FullName)) {
                    $ListBox.Items.Add($pdf.FullName) | Out-Null
                }
            }
        }
        else {
            if ([System.IO.Path]::GetExtension($path) -ieq ".pdf") {
                if (-not $ListBox.Items.Contains($path)) {
                    $ListBox.Items.Add($path) | Out-Null
                }
            }
        }
    }
}

# -----------------------------------------
# Build GUI
# -----------------------------------------
$form = New-Object System.Windows.Forms.Form
$form.Text = "DeLucs PDF Merger"
$form.Size = New-Object System.Drawing.Size(600, 420)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::FromArgb(32,32,32)
$form.ForeColor = [System.Drawing.Color]::White
$form.Font = New-Object System.Drawing.Font("Segoe UI", 9)

$label = New-Object System.Windows.Forms.Label
$label.Text = "Selected PDF files (drag & drop here):"
$label.AutoSize = $true
$label.Location = New-Object System.Drawing.Point(20, 20)
$form.Controls.Add($label)

$fileListBox = New-Object System.Windows.Forms.ListBox
$fileListBox.Location = New-Object System.Drawing.Point(20, 45)
$fileListBox.Size = New-Object System.Drawing.Size(540, 200)
$fileListBox.BackColor = [System.Drawing.Color]::FromArgb(45,45,45)
$fileListBox.ForeColor = [System.Drawing.Color]::White
$fileListBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$fileListBox.SelectionMode = "MultiExtended"
$fileListBox.AllowDrop = $true
$form.Controls.Add($fileListBox)

# Drag & Drop handlers
$fileListBox.Add_DragEnter({
    if ($_.Data.GetDataPresent([System.Windows.Forms.DataFormats]::FileDrop)) {
        $_.Effect = [System.Windows.Forms.DragDropEffects]::Copy
    } else {
        $_.Effect = [System.Windows.Forms.DragDropEffects]::None
    }
})

$fileListBox.Add_DragDrop({
    $files = $_.Data.GetData([System.Windows.Forms.DataFormats]::FileDrop)
    Add-FilesToListBox -ListBox $fileListBox -Paths $files
})

# Buttons
$btnAdd = New-Object System.Windows.Forms.Button
$btnAdd.Text = "Add PDFs..."
$btnAdd.Location = New-Object System.Drawing.Point(20, 260)
$btnAdd.Size = New-Object System.Drawing.Size(100, 30)
$btnAdd.BackColor = [System.Drawing.Color]::FromArgb(64,64,64)
$btnAdd.ForeColor = [System.Drawing.Color]::White
$btnAdd.FlatStyle = 'Flat'
$btnAdd.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = "PDF files (*.pdf)|*.pdf"
    $dlg.Multiselect = $true
    if ($dlg.ShowDialog() -eq "OK") {
        Add-FilesToListBox -ListBox $fileListBox -Paths $dlg.FileNames
    }
})
$form.Controls.Add($btnAdd)

$btnRemove = New-Object System.Windows.Forms.Button
$btnRemove.Text = "Remove selected"
$btnRemove.Location = New-Object System.Drawing.Point(130, 260)
$btnRemove.Size = New-Object System.Drawing.Size(120, 30)
$btnRemove.BackColor = [System.Drawing.Color]::FromArgb(64,64,64)
$btnRemove.ForeColor = [System.Drawing.Color]::White
$btnRemove.FlatStyle = 'Flat'
$btnRemove.Add_Click({
    $toRemove = @($fileListBox.SelectedItems)
    foreach ($item in $toRemove) {
        $fileListBox.Items.Remove($item)
    }
})
$form.Controls.Add($btnRemove)

$btnUp = New-Object System.Windows.Forms.Button
$btnUp.Text = "Move up"
$btnUp.Location = New-Object System.Drawing.Point(260, 260)
$btnUp.Size = New-Object System.Drawing.Size(90, 30)
$btnUp.BackColor = [System.Drawing.Color]::FromArgb(64,64,64)
$btnUp.ForeColor = [System.Drawing.Color]::White
$btnUp.FlatStyle = 'Flat'
$btnUp.Add_Click({
    if ($fileListBox.SelectedIndices.Count -eq 1) {
        $idx = $fileListBox.SelectedIndex
        if ($idx -gt 0) {
            $item = $fileListBox.Items[$idx]
            $fileListBox.Items.RemoveAt($idx)
            $fileListBox.Items.Insert($idx - 1, $item)
            $fileListBox.SelectedIndex = $idx - 1
        }
    }
})
$form.Controls.Add($btnUp)

$btnDown = New-Object System.Windows.Forms.Button
$btnDown.Text = "Move down"
$btnDown.Location = New-Object System.Drawing.Point(360, 260)
$btnDown.Size = New-Object System.Drawing.Size(90, 30)
$btnDown.BackColor = [System.Drawing.Color]::FromArgb(64,64,64)
$btnDown.ForeColor = [System.Drawing.Color]::White
$btnDown.FlatStyle = 'Flat'
$btnDown.Add_Click({
    if ($fileListBox.SelectedIndices.Count -eq 1) {
        $idx = $fileListBox.SelectedIndex
        if ($idx -ge 0 -and $idx -lt $fileListBox.Items.Count - 1) {
            $item = $fileListBox.Items[$idx]
            $fileListBox.Items.RemoveAt($idx)
            $fileListBox.Items.Insert($idx + 1, $item)
            $fileListBox.SelectedIndex = $idx + 1
        }
    }
})
$form.Controls.Add($btnDown)

$chkSort = New-Object System.Windows.Forms.CheckBox
$chkSort.Text = "Sort alphabetically before merge"
$chkSort.AutoSize = $true
$chkSort.Location = New-Object System.Drawing.Point(20, 300)
$form.Controls.Add($chkSort)

$progressBar = New-Object System.Windows.Forms.ProgressBar
$progressBar.Location = New-Object System.Drawing.Point(20, 330)
$progressBar.Size = New-Object System.Drawing.Size(540, 18)
$progressBar.Style = 'Continuous'
$form.Controls.Add($progressBar)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = "Ready."
$statusLabel.AutoSize = $false
$statusLabel.Location = New-Object System.Drawing.Point(20, 355)
$statusLabel.Size = New-Object System.Drawing.Size(540, 40)
$statusLabel.ForeColor = [System.Drawing.Color]::LightGray
$form.Controls.Add($statusLabel)

$btnMerge = New-Object System.Windows.Forms.Button
$btnMerge.Text = "Merge && Save..."
$btnMerge.Location = New-Object System.Drawing.Point(460, 260)
$btnMerge.Size = New-Object System.Drawing.Size(100, 30)
$btnMerge.BackColor = [System.Drawing.Color]::FromArgb(0,122,204)
$btnMerge.ForeColor = [System.Drawing.Color]::White
$btnMerge.FlatStyle = 'Flat'
$btnMerge.Add_Click({
    if ($fileListBox.Items.Count -lt 2) {
        [System.Windows.Forms.MessageBox]::Show("Please add at least 2 PDF files.", "DeLucs PDF Merger")
        return
    }

    $files = @()
    foreach ($item in $fileListBox.Items) {
        $files += [string]$item
    }

    if ($chkSort.Checked) {
        $files = $files | Sort-Object
    }

    $saveDlg = New-Object System.Windows.Forms.SaveFileDialog
    $saveDlg.Filter = "PDF file (*.pdf)|*.pdf"
    $saveDlg.FileName = "merged.pdf"

    if ($saveDlg.ShowDialog() -ne "OK") { return }

    try {
        $statusLabel.Text = "Preparing to merge..."
        $progressBar.Value = 0
        [System.Windows.Forms.Application]::DoEvents()

        Merge-PDFsGhostscript -Files $files -Output $saveDlg.FileName -StatusLabel $statusLabel
        $progressBar.Value = 100
        [System.Windows.Forms.MessageBox]::Show("Merged PDF saved to:`n$($saveDlg.FileName)", "PDF Merger (Ghostscript)")
    }
    catch {
        $statusLabel.Text = "Error: $($_.Exception.Message)"
        [System.Windows.Forms.MessageBox]::Show("Error while merging PDFs:`n$($_.Exception.Message)", "Error")
    }
})
$form.Controls.Add($btnMerge)

$form.Topmost = $true
$form.Add_Shown({ $form.Activate() })
[System.Windows.Forms.Application]::Run($form)
